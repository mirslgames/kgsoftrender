package com.cgvsu.math.vectors;

import com.cgvsu.math.vectors.AbstractVector;

public class Vector2f extends AbstractVector<Vector2f> {

    public Vector2f() {
        super(2);
    }

    public Vector2f(float x, float y) {
        super(new float[]{x, y});
    }

    @Override
    protected Vector2f create(float[] coordinates) {
        return new Vector2f(coordinates[0], coordinates[1]);
    }

    public float getX() {
        return getValue(0);
    }

    public float getY() {
        return getValue(1);
    }

    public void setX(float x) {
        setValue(0, x);
    }

    public void setY(float y) {
        setValue(1, y);
    }
}
