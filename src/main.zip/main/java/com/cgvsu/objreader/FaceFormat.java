package com.cgvsu.objreader;

public enum FaceFormat {
    V,          // "1"
    V_VT,       // "1/2"
    V_VN,       // "1//3"
    V_VT_VN     // "1/2/3"
}
