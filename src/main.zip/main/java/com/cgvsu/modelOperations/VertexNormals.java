package com.cgvsu.modelOperations;

public interface VertexNormals<V> {

    public void calculateVertexNormals(V Model);


}
